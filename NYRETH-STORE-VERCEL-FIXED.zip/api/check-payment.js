const https = require('https');

// For production, set NASIONALPAY_STORE_KEY in Vercel Environment Variables.
const STORE_KEY = process.env.NASIONALPAY_STORE_KEY || 'SK_fe4c8a1233f8456c33d1bb0d799674e7d29e645f874bae227b75edead0';
const API = 'https://merchant.nasionalpay.com/api/payment/status';

module.exports = async function handler(req,res){
  if(req.method!=='POST') return send(res,405,{ok:false,error:'Method Not Allowed'});
  try{
    const body=typeof req.body==='string'?JSON.parse(req.body||'{}'):(req.body||{});
    const transaction_id=String(body.transaction_id||'');
    if(!transaction_id) return send(res,400,{ok:false,error:'transaction_id required'});
    const r=await post(API,{key:STORE_KEY,transaction_id});
    if(!r.ok) return send(res,r.httpStatus,{ok:false,error:r.error||'NasionalPay error',data:r.data});
    const d=r.data||{};
    const status=String(d.status||d.data?.status||d.payment_status||d.data?.payment_status||'').toLowerCase();
    return send(res,200,{ok:true,status,paid:['paid','success','successful','completed','settlement','settled'].includes(status),data:d});
  }catch(e){return send(res,500,{ok:false,error:e.message})}
};
function post(url,payload){return new Promise(resolve=>{
  const u=new URL(url); const req=https.request({hostname:u.hostname,path:u.pathname,method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'}},res=>{
    let s='';res.on('data',c=>s+=c);res.on('end',()=>{let data;try{data=JSON.parse(s)}catch{data=null};resolve({httpStatus:res.statusCode,ok:res.statusCode>=200&&res.statusCode<300&&!!data,error:data?.message||data?.error||(!data?'Empty/non-JSON response':null),data})});
  });
  req.on('error',e=>resolve({httpStatus:502,ok:false,error:e.message}));
  req.setTimeout(20000,()=>{req.destroy();resolve({httpStatus:504,ok:false,error:'NasionalPay timeout'})});
  req.write(JSON.stringify(payload));req.end();
})}
function send(res,status,obj){res.status(status).setHeader('Cache-Control','no-store').json(obj)}
