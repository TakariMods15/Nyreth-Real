NYRETH-STORE — VERCEL

Deploy this folder/ZIP to Vercel.

Environment Variable (recommended):
NASIONALPAY_STORE_KEY = your NasionalPay Store Key

The current API files also contain the Store Key fallback supplied for testing. For a public production deployment, remove the fallback and use the Vercel environment variable, then rotate the key because it was previously shared.

API routes:
POST /api/create-qris
POST /api/check-payment
